﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarBaoYang.ResultJson
{
   
        public class Brands
        {
            public string Code { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public string LogUrl { get; set; }
            public string FirstPinYin { get; set; }
        }

    
}