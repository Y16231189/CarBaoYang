﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarBaoYang.ResultJson
{
    public class manufacturer
    {
        public string Category { get; set; }
        public string Serie { get; set; }
        public string ModelName { get; set; }
        public string ManufacturerName { get; set; }
        public string BrandCode { get; set; }
        public string BrandName { get; set; }
        public string ManufacturerCode { get; set; }
    }

}